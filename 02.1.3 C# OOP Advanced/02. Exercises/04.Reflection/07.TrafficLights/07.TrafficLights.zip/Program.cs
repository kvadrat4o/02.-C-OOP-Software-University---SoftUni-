﻿using System;

namespace _07.TrafficLights
{
    class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
