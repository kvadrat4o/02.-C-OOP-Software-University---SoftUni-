﻿using System;
using System.Collections.Generic;
using System.Text;

public enum LightColor
{
    Red,
    Green,
    Yellow
}
