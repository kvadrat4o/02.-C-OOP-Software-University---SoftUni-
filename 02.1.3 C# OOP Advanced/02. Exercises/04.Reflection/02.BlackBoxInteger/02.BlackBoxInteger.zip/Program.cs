﻿using System;

namespace _02.BlackBoxInteger
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new BlackBoxIntegerTests().Black());
        }
    }
}
