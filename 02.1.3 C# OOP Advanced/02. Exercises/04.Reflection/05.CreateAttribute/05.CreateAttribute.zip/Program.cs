﻿using System;

namespace _05.CreateAttribute
{
    [SoftUni("Work")]
    class Program
    {
        [SoftUni("Sample")]
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
