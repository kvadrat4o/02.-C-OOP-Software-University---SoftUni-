﻿using System;
using System.Collections.Generic;

namespace _06.CustomEnumAttribute
{
    class Program
    {
        static void Main(string[] args)
        {
            new Engine().Run();
        }
    }
}
