﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IIdentifier
{
    long Id { get; }
}
