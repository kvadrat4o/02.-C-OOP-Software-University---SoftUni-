﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ITweet
{
    void ReceiveMessage(string message);
}