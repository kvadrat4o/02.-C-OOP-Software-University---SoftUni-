﻿using System;
using System.Collections.Generic;
using System.Text;

public class InputWriter
{
    public void WriteInputOnANewLine(string message) => Console.WriteLine(message);
}
