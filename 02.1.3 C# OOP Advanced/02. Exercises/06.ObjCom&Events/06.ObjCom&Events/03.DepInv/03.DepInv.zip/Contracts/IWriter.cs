﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03.DepInv.Contracts
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
