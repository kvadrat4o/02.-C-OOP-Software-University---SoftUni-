﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _01.Event.Contracts
{
    public interface IWriter
    {
        void WriteLine(string line);
    }
}
