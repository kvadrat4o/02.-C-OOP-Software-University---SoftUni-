﻿using System;

namespace _02.MultipleInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Puppy pup = new Puppy();
            pup.Bark();
            pup.Weep();
            pup.Eat();
                
        }
    }
}
