﻿using System;
using System.Collections.Generic;
using System.Text;

public class Cat : Animal
{
    public void Meow()
    {
        global::System.Console.WriteLine("meowing...");
    }
}
