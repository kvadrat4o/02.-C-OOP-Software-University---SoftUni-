﻿using System;
using System.Collections.Generic;
using System.Text;

public interface ISoldier
{
    string FirstName { get; }

    string LastName { get; }

    string Id { get; }
}
