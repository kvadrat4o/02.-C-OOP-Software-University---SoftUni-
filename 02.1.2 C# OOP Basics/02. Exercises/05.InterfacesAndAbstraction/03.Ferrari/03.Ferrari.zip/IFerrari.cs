﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IFerrari
{
    string Driver { get; }

    string Breaks();

    string PushTheGasPedal();
}
