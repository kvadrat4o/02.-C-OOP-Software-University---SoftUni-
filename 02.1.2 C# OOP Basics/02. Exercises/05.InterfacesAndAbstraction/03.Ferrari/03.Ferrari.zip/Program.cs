﻿using System;

namespace _03.Ferraris
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine(new Ferrari(Console.ReadLine()));
        }
    }
}
