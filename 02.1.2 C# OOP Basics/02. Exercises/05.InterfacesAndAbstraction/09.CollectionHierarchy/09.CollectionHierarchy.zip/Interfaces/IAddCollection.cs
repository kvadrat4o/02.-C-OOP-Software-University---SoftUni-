﻿using System;
using System.Collections.Generic;
using System.Text;

public interface IAddCollection
{
    int Add(string st);
}
