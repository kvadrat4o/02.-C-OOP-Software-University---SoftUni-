﻿public enum Toppingtype
{
    Meat,
    Veggies,
    Cheese,
    Sauce
}