﻿using System;
using System.Collections.Generic;
using System.Text;

public enum BakingTechnique
{
    Crispy,
    Chewy,
    Homemade
}
