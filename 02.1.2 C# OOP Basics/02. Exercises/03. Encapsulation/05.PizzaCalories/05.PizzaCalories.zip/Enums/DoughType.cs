﻿public enum DoughType
{
    White,
    Wholegrain
}
