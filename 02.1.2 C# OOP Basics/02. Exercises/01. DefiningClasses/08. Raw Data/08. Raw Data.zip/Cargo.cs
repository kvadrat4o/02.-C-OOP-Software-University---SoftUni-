﻿
public class Cargo
{
    private int weight;
    private string cargotype;

    public string CargoType
    {
        get { return cargotype; }
        set { cargotype = value; }
    }
    public int Weight
    {
        get { return weight; }
        set { weight = value; }
    }

    public Cargo()
    {

    }
}
