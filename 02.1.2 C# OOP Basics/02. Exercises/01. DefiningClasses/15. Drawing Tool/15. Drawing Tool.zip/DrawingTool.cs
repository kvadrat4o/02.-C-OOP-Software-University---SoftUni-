﻿public class DrawingTool
{
    private Square square;
    private Rectangle rectangle;

    public Square Square
    {
        get { return square; }
        set { square = value; }
    }
   
    public Rectangle Rectangle
    {
        get { return rectangle; }
        set { rectangle = value; }
    }

    public DrawingTool()
    {

    }
}
