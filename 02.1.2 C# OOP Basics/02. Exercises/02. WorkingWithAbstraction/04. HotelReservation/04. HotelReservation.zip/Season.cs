﻿public enum Season
{
    Spring,
    Summer,
    Autumn,
    Winter
}