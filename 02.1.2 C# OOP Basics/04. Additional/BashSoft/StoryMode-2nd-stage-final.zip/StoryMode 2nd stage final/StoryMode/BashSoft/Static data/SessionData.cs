﻿using System.IO;

class SessionData
{
    public static string currentPath = Directory.GetCurrentDirectory();
}
