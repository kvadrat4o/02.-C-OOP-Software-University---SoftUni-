﻿using System;
using System.Collections.Generic;
using System.Text;

public class Exceptions
{
    public const string minOreOutput = "Harvester is not registered, because of it's OreOutput";

    public const string maxEnergyRequirement = "Harvester is not registered, because of it's EnergyRequirement";

    public const string providerEnergy = "Provider is not registered, because of it's EnergyOutput";
}